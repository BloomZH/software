# encoding: utf-8
# module _codecs_tw
# from (built-in)
# by generator 1.147
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    """  """
    pass

# no classes
# variables with complex values

__map_big5 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x0000000002570480>'

__map_cp950ext = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x00000000025704E0>'

