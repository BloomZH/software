# encoding: utf-8
# module _sha512
# from (built-in)
# by generator 1.147
# no doc
# no imports

# functions

def sha384(*args, **kwargs): # real signature unknown
    """ Return a new SHA-384 hash object; optionally initialized with a string. """
    pass

def sha512(*args, **kwargs): # real signature unknown
    """ Return a new SHA-512 hash object; optionally initialized with a string. """
    pass

# no classes
