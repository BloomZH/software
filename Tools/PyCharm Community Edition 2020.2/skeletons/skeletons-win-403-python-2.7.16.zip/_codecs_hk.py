# encoding: utf-8
# module _codecs_hk
# from (built-in)
# by generator 1.147
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    """  """
    pass

# no classes
# variables with complex values

__map_big5hkscs = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x00000000025C0480>'

__map_big5hkscs_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x00000000025C04E0>'

__map_big5hkscs_nonbmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x00000000025C0510>'

